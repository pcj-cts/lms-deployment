import * as cdk from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as ecs from "aws-cdk-lib/aws-ecs";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as elbv2 from "aws-cdk-lib/aws-elasticloadbalancingv2";
import * as iam from "aws-cdk-lib/aws-iam";
import * as logs from "aws-cdk-lib/aws-logs";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sns from "aws-cdk-lib/aws-sns";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import * as applicationautoscaling from "aws-cdk-lib/aws-applicationautoscaling";
import { Construct } from "constructs";
import { SecurityGroups } from "./foundation-stack";
import { SnsTopics, SqsQueues } from "./data-stack";

// ── Microservice catalogue ────────────────────────────────────────
// Matches architecture doc section 3 exactly: port, CPU, memory per service.
const SERVICES: ServiceConfig[] = [
  { name: "auth",         port: 8081, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
  { name: "user",         port: 8082, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
  { name: "course",       port: 8083, cpu: 1024, memory: 2048, minTasks: 1, maxTasks: 6  },
  { name: "enrolment",    port: 8084, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
  { name: "assessment",   port: 8085, cpu: 1024, memory: 2048, minTasks: 1, maxTasks: 6  },
  { name: "progress",     port: 8086, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
  { name: "notification", port: 8087, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
  { name: "logging",      port: 8088, cpu: 512,  memory: 1024, minTasks: 1, maxTasks: 4  },
];

interface ServiceConfig {
  name: string;
  port: number;
  cpu: number;
  memory: number;
  minTasks: number;
  maxTasks: number;
}

interface AppStackProps extends cdk.StackProps {
  vpc: ec2.Vpc;
  securityGroups: SecurityGroups;
  dbSecret: secretsmanager.Secret;
  jwtSecret: secretsmanager.Secret;
  rdsEndpoint: string;
  redisEndpoint: string;
  contentBucket: s3.Bucket;
  certsBucket: s3.Bucket;
  submissionsBucket: s3.Bucket;
  snsTopics: SnsTopics;
  sqsQueues: SqsQueues;
}

export class LmsAppStack extends cdk.Stack {
  public readonly alb: elbv2.ApplicationLoadBalancer;
  public readonly ecsServices: Record<string, ecs.FargateService>;
  public readonly ecrRepos: Record<string, ecr.Repository>;

  constructor(scope: Construct, id: string, props: AppStackProps) {
    super(scope, id, props);
    const { vpc, securityGroups, dbSecret, jwtSecret } = props;

    // ── ECR Repositories ──────────────────────────────────────────────
    // One private repo per service, image scanning on push, keep last 10 images.
    this.ecrRepos = {};
    for (const svc of SERVICES) {
      this.ecrRepos[svc.name] = new ecr.Repository(this, `EcrRepo${svc.name}`, {
        repositoryName: `lms/${svc.name}-service`,
        imageScanOnPush: true,
        lifecycleRules: [
          { maxImageCount: 10, description: "Keep last 10 images" },
        ],
        removalPolicy: cdk.RemovalPolicy.RETAIN,
      });
    }

    // ── ECS Cluster ───────────────────────────────────────────────────
    const cluster = new ecs.Cluster(this, "LmsCluster", {
      clusterName: "lms-fargate-cluster",
      vpc,
      containerInsights: true,           // CloudWatch Container Insights
    });

    // ── Application Load Balancer ─────────────────────────────────────
    // Modified architecture v1.1: ALB added at API Gateway layer.
    // HTTPS listener routes by path prefix to each service's target group.
    this.alb = new elbv2.ApplicationLoadBalancer(this, "LmsAlb", {
      loadBalancerName: "lms-alb",
      vpc,
      internetFacing: true,
      securityGroup: securityGroups.alb,
      vpcSubnets: { subnetType: ec2.SubnetType.PUBLIC },
      deletionProtection: true,
    });

    // HTTP → HTTPS redirect
    this.alb.addListener("HttpListener", {
      port: 80,
      defaultAction: elbv2.ListenerAction.redirect({
        protocol: "HTTPS",
        port: "443",
        permanent: true,
      }),
    });

    const httpsListener = this.alb.addListener("HttpsListener", {
      port: 443,
      protocol: elbv2.ApplicationProtocol.HTTPS,
      // ACM certificate added in TrafficStack via addCertificates()
      certificates: [],
      defaultAction: elbv2.ListenerAction.fixedResponse(404, {
        contentType: "application/json",
        messageBody: '{"error":"route not found"}',
      }),
      open: false,
    });

    // ── ECS Task Role ─────────────────────────────────────────────────
    // Shared task role – least-privilege per service is done via conditional
    // resource ARN scoping on S3 and SQS actions.
    const taskRole = new iam.Role(this, "EcsTaskRole", {
      roleName: "lms-ecs-task-role",
      assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
    });

    // S3 access: content read, submissions read/write, certs write
    taskRole.addToPolicy(new iam.PolicyStatement({
      sid: "S3Access",
      actions: ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:GeneratePresignedUrl"],
      resources: [
        props.contentBucket.arnForObjects("*"),
        props.submissionsBucket.arnForObjects("*"),
        props.certsBucket.arnForObjects("*"),
      ],
    }));

    // SNS publish
    const topicArns = Object.values(props.snsTopics).map((t) => t.topicArn);
    taskRole.addToPolicy(new iam.PolicyStatement({
      sid: "SnsPublish",
      actions: ["sns:Publish"],
      resources: topicArns,
    }));

    // SQS send/receive
    const queueArns = Object.values(props.sqsQueues).map((q) => q.queueArn);
    taskRole.addToPolicy(new iam.PolicyStatement({
      sid: "SqsAccess",
      actions: ["sqs:SendMessage", "sqs:ReceiveMessage", "sqs:DeleteMessage"],
      resources: queueArns,
    }));

    // Secrets Manager read
    taskRole.addToPolicy(new iam.PolicyStatement({
      sid: "SecretsRead",
      actions: ["secretsmanager:GetSecretValue"],
      resources: [dbSecret.secretArn, jwtSecret.secretArn],
    }));

    // X-Ray tracing
    taskRole.addToPolicy(new iam.PolicyStatement({
      sid: "XRayWrite",
      actions: ["xray:PutTraceSegments", "xray:PutTelemetryRecords"],
      resources: ["*"],
    }));

    // ── Fargate Services ──────────────────────────────────────────────
    // One FargateService per microservice with:
    //   - ALB path-based routing
    //   - /actuator/health health checks
    //   - CPU-based auto-scaling (> 60% triggers scale-out)
    //   - CloudWatch log group per service
    //   - X-Ray daemon sidecar
    this.ecsServices = {};

    const pathPrefixes: Record<string, string> = {
      auth:         "/api/auth/*",
      user:         "/api/users/*",
      course:       "/api/courses/*",
      enrolment:    "/api/enrollments/*",
      assessment:   "/api/assessments/*",
      progress:     "/api/progress/*",
      notification: "/api/notifications/*",
      logging:      "/api/logs/*",
    };

    SERVICES.forEach((svc, index) => {
      const logGroup = new logs.LogGroup(this, `LogGroup${svc.name}`, {
        logGroupName: `/lms/ecs/${svc.name}-service`,
        retention: logs.RetentionDays.ONE_MONTH,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
      });

      const taskDef = new ecs.FargateTaskDefinition(this, `TaskDef${svc.name}`, {
        family: `lms-${svc.name}-service`,
        cpu: svc.cpu,
        memoryLimitMiB: svc.memory,
        taskRole,
        // executionRole comes from CDK defaults (AmazonECSTaskExecutionRolePolicy)
      });

      // Main application container
      const container = taskDef.addContainer(`${svc.name}Container`, {
        containerName: svc.name,
        // On first deploy the image must exist in ECR. Use a placeholder until
        // your CI/CD pipeline pushes the real image.
        image: ecs.ContainerImage.fromEcrRepository(
          this.ecrRepos[svc.name],
          "latest"
        ),
        portMappings: [{ containerPort: svc.port, protocol: ecs.Protocol.TCP }],
        environment: {
          SPRING_PROFILES_ACTIVE:     "production",
          SERVER_PORT:                String(svc.port),
          DB_HOST:                    props.rdsEndpoint,
          DB_NAME:                    "lmsdb",
          REDIS_ENDPOINT:             props.redisEndpoint,
          CONTENT_BUCKET:             props.contentBucket.bucketName,
          SUBMISSIONS_BUCKET:         props.submissionsBucket.bucketName,
          CERTS_BUCKET:               props.certsBucket.bucketName,
          SNS_GRADE_RELEASED_ARN:     props.snsTopics.gradeReleased.topicArn,
          SNS_ENROLMENT_CONFIRMED_ARN:props.snsTopics.enrolmentConfirmed.topicArn,
          SNS_COURSE_COMPLETED_ARN:   props.snsTopics.courseCompleted.topicArn,
          SQS_AUTO_GRADE_URL:         props.sqsQueues.autoGrade.queueUrl,
          SQS_PROGRESS_URL:           props.sqsQueues.progress.queueUrl,
          AWS_REGION:                 this.region,
          JAVA_TOOL_OPTIONS:          "-XX:+UseContainerSupport -XX:MaxRAMPercentage=75.0",
        },
        secrets: {
          DB_PASSWORD: ecs.Secret.fromSecretsManager(dbSecret, "password"),
          DB_USERNAME: ecs.Secret.fromSecretsManager(dbSecret, "username"),
          JWT_SECRET:  ecs.Secret.fromSecretsManager(jwtSecret, "secret"),
        },
        logging: ecs.LogDrivers.awsLogs({
          logGroup,
          streamPrefix: svc.name,
        }),
        healthCheck: {
          command: [
            "CMD-SHELL",
            `curl -f http://localhost:${svc.port}/actuator/health || exit 1`,
          ],
          interval: cdk.Duration.seconds(30),
          timeout: cdk.Duration.seconds(10),
          retries: 3,
          startPeriod: cdk.Duration.seconds(60),
        },
      });

      // X-Ray daemon sidecar – distributed tracing across all services
      taskDef.addContainer(`${svc.name}XRay`, {
        containerName: "xray-daemon",
        image: ecs.ContainerImage.fromRegistry("amazon/aws-xray-daemon"),
        essential: false,
        portMappings: [{ containerPort: 2000, protocol: ecs.Protocol.UDP }],
        logging: ecs.LogDrivers.awsLogs({
          logGroup,
          streamPrefix: `${svc.name}-xray`,
        }),
        cpu: 32,
        memoryReservationMiB: 64,
      });

      // Fargate service – spread across both AZs, min 1 task per AZ
      const fargateService = new ecs.FargateService(this, `FargateSvc${svc.name}`, {
        serviceName: `lms-${svc.name}-service`,
        cluster,
        taskDefinition: taskDef,
        desiredCount: 2,                     // 1 task per AZ minimum
        assignPublicIp: false,               // Private subnet only
        vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
        securityGroups: [securityGroups.ecs],
        enableExecuteCommand: true,          // ECS Exec for debugging
        circuitBreaker: { rollback: true },  // Auto-rollback on health failure
        deploymentController: {
          type: ecs.DeploymentControllerType.CODE_DEPLOY,
        },
      });

      // ALB target group + path-based routing rule
      const targetGroup = new elbv2.ApplicationTargetGroup(
        this,
        `TG${svc.name}`,
        {
          targetGroupName: `lms-tg-${svc.name}`,
          vpc,
          port: svc.port,
          protocol: elbv2.ApplicationProtocol.HTTP,
          targets: [fargateService],
          healthCheck: {
            path: "/actuator/health",
            interval: cdk.Duration.seconds(30),
            healthyHttpCodes: "200",
            healthyThresholdCount: 2,
            unhealthyThresholdCount: 3,
          },
          deregistrationDelay: cdk.Duration.seconds(30),
        }
      );

      httpsListener.addAction(`Route${svc.name}`, {
        priority: (index + 1) * 10,
        conditions: [
          elbv2.ListenerCondition.pathPatterns([pathPrefixes[svc.name]]),
        ],
        action: elbv2.ListenerAction.forward([targetGroup]),
      });

      // CPU-based auto-scaling: scale out when CPU > 60% for 3 minutes
      const scalingTarget = fargateService.autoScaleTaskCount({
        minCapacity: svc.minTasks,
        maxCapacity: svc.maxTasks,
      });
      scalingTarget.scaleOnCpuUtilization(`${svc.name}CpuScaling`, {
        targetUtilizationPercent: 60,
        scaleInCooldown: cdk.Duration.minutes(5),
        scaleOutCooldown: cdk.Duration.minutes(2),
      });

      this.ecsServices[svc.name] = fargateService;
    });

    // ── Outputs ──────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "AlbDnsName", {
      value: this.alb.loadBalancerDnsName,
      exportName: "LmsAlbDnsName",
    });
    new cdk.CfnOutput(this, "EcsClusterName", {
      value: cluster.clusterName,
      exportName: "LmsEcsClusterName",
    });
  }
}
