import * as cdk from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as rds from "aws-cdk-lib/aws-rds";
import * as elasticache from "aws-cdk-lib/aws-elasticache";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sns from "aws-cdk-lib/aws-sns";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as kms from "aws-cdk-lib/aws-kms";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import { Construct } from "constructs";
import { SecurityGroups } from "./foundation-stack";

interface DataStackProps extends cdk.StackProps {
  vpc: ec2.Vpc;
  securityGroups: SecurityGroups;
  kmsKey: kms.Key;
  dbSecret: secretsmanager.Secret;
}

export interface SnsTopics {
  gradeReleased: sns.Topic;
  enrolmentConfirmed: sns.Topic;
  courseCompleted: sns.Topic;
  deadlineReminder: sns.Topic;
  coursePublished: sns.Topic;
  certificateReady: sns.Topic;
}

export interface SqsQueues {
  autoGrade: sqs.Queue;
  autoGradeDlq: sqs.Queue;
  progress: sqs.Queue;
  progressDlq: sqs.Queue;
  notification: sqs.Queue;
  notificationDlq: sqs.Queue;
  logIngestion: sqs.Queue;
  logIngestionDlq: sqs.Queue;
}

export class LmsDataStack extends cdk.Stack {
  public readonly rdsEndpoint: string;
  public readonly redisEndpoint: string;
  public readonly contentBucket: s3.Bucket;
  public readonly submissionsBucket: s3.Bucket;
  public readonly certsBucket: s3.Bucket;
  public readonly snsTopics: SnsTopics;
  public readonly sqsQueues: SqsQueues;

  constructor(scope: Construct, id: string, props: DataStackProps) {
    super(scope, id, props);
    const { vpc, securityGroups, kmsKey, dbSecret } = props;

    // ── RDS PostgreSQL Multi-AZ ──────────────────────────────────────
    // Architecture doc section 2.4: db.t3.medium, Multi-AZ, 7-day backups,
    // Performance Insights, read replica for reporting queries.
    const dbSubnetGroup = new rds.SubnetGroup(this, "RdsSubnetGroup", {
      description: "LMS RDS isolated subnets",
      vpc,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    const rdsInstance = new rds.DatabaseInstance(this, "LmsRdsPostgres", {
      instanceIdentifier: "lms-postgres",
      engine: rds.DatabaseInstanceEngine.postgres({
        version: rds.PostgresEngineVersion.VER_15_6,
      }),
      instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.T3,
        ec2.InstanceSize.MEDIUM
      ),
      vpc,
      subnetGroup: dbSubnetGroup,
      securityGroups: [securityGroups.rds],
      credentials: rds.Credentials.fromSecret(dbSecret),
      databaseName: "lmsdb",
      multiAz: true,                          // Synchronous standby in second AZ
      allocatedStorage: 100,
      maxAllocatedStorage: 500,               // Autoscaling up to 500 GB
      storageType: rds.StorageType.GP3,
      storageEncrypted: true,
      storageEncryptionKey: kmsKey,
      backupRetention: cdk.Duration.days(7),  // RPO < 5 min via PITR
      enablePerformanceInsights: true,
      performanceInsightRetention: rds.PerformanceInsightRetention.DEFAULT,
      deletionProtection: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      cloudwatchLogsExports: ["postgresql", "upgrade"],
      autoMinorVersionUpgrade: true,
    });

    this.rdsEndpoint = rdsInstance.dbInstanceEndpointAddress;

    // Read replica for reporting queries (cohort reports, grade distribution)
    new rds.DatabaseInstanceReadReplica(this, "LmsRdsReadReplica", {
      instanceIdentifier: "lms-postgres-replica",
      sourceDatabaseInstance: rdsInstance,
      instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.T3,
        ec2.InstanceSize.MEDIUM
      ),
      vpc,
      subnetGroup: dbSubnetGroup,
      securityGroups: [securityGroups.rds],
    });

    // ── ElastiCache Redis Cluster ────────────────────────────────────
    // Architecture doc section 2.4: cluster mode, 2 shards × 2 replicas,
    // encryption at rest and in transit, allkeys-lru eviction.
    const redisSubnetGroup = new elasticache.CfnSubnetGroup(
      this,
      "RedisSubnetGroup",
      {
        description: "LMS Redis isolated subnets",
        subnetIds: vpc.selectSubnets({
          subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
        }).subnetIds,
        cacheSubnetGroupName: "lms-redis-subnet-group",
      }
    );

    const redisCluster = new elasticache.CfnReplicationGroup(
      this,
      "LmsRedisCluster",
      {
        replicationGroupDescription: "LMS ElastiCache Redis – sessions, cache, preferences",
        replicationGroupId: "lms-redis",
        cacheNodeType: "cache.t3.medium",
        engine: "redis",
        engineVersion: "7.1",
        numNodeGroups: 2,                    // 2 shards
        replicasPerNodeGroup: 1,             // 1 replica each = 2 shards × 2 replicas
        automaticFailoverEnabled: true,
        multiAzEnabled: true,
        atRestEncryptionEnabled: true,
        transitEncryptionEnabled: true,
        cacheSubnetGroupName: redisSubnetGroup.cacheSubnetGroupName,
        securityGroupIds: [securityGroups.redis.securityGroupId],
        snapshotRetentionLimit: 1,
      }
    );
    redisCluster.addDependency(redisSubnetGroup);
    this.redisEndpoint =
      redisCluster.attrConfigurationEndPointAddress +
      ":" +
      redisCluster.attrConfigurationEndPointPort;

    // ── DynamoDB Tables ──────────────────────────────────────────────
    // Logs table: on-demand capacity, 90-day TTL, PITR enabled
    // Partition key: actorId#date prefix to avoid hot partitions (architecture doc risk #2)
    const logsTable = new dynamodb.Table(this, "LmsLogsTable", {
      tableName: "lms-logs",
      partitionKey: { name: "actorIdDate", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "timestamp", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.CUSTOMER_MANAGED,
      encryptionKey: kmsKey,
      timeToLiveAttribute: "ttl",             // 90-day log retention
      pointInTimeRecovery: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // GSI for event type queries (Admin log viewer by event type + date range)
    logsTable.addGlobalSecondaryIndex({
      indexName: "eventType-timestamp-index",
      partitionKey: { name: "eventType", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "timestamp", type: dynamodb.AttributeType.STRING },
    });

    // Progress events table for lesson view events
    new dynamodb.Table(this, "LmsProgressEventsTable", {
      tableName: "lms-progress-events",
      partitionKey: { name: "enrollmentId", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "lessonId", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.CUSTOMER_MANAGED,
      encryptionKey: kmsKey,
      pointInTimeRecovery: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // ── S3 Buckets ───────────────────────────────────────────────────
    // Architecture doc section 2.4: versioning, SSE-S3, lifecycle to Glacier after 1 year
    const bucketDefaults: Partial<s3.BucketProps> = {
      versioned: true,
      encryption: s3.BucketEncryption.KMS,
      encryptionKey: kmsKey,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      enforceSSL: true,
      lifecycleRules: [
        {
          transitions: [
            {
              storageClass: s3.StorageClass.GLACIER,
              transitionAfter: cdk.Duration.days(365),
            },
          ],
        },
      ],
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    };

    this.contentBucket = new s3.Bucket(this, "LmsContentBucket", {
      ...bucketDefaults,
      bucketName: `lms-content-${this.account}-${this.region}`,
      cors: [
        {
          allowedMethods: [s3.HttpMethods.GET, s3.HttpMethods.PUT],
          allowedOrigins: ["https://*.lms.example.com"],
          allowedHeaders: ["*"],
          maxAge: 3000,
        },
      ],
    });

    this.submissionsBucket = new s3.Bucket(this, "LmsSubmissionsBucket", {
      ...bucketDefaults,
      bucketName: `lms-submissions-${this.account}-${this.region}`,
    });

    this.certsBucket = new s3.Bucket(this, "LmsCertsBucket", {
      ...bucketDefaults,
      bucketName: `lms-certificates-${this.account}-${this.region}`,
    });

    // Cross-region replication for content bucket durability (architecture doc section 7.2)
    // NOTE: Requires a replication destination bucket in a second region.
    // Uncomment and set destBucketArn once created:
    // this.contentBucket.addReplicationRules({ ... })

    // ── SNS Topics ───────────────────────────────────────────────────
    // Architecture doc section 2.3: grade-released, enrolment-confirmed,
    // course-completed, deadline-reminder
    this.snsTopics = {
      gradeReleased: new sns.Topic(this, "GradeReleasedTopic", {
        topicName: "lms-grade-released",
        masterKey: kmsKey,
      }),
      enrolmentConfirmed: new sns.Topic(this, "EnrolmentConfirmedTopic", {
        topicName: "lms-enrolment-confirmed",
        masterKey: kmsKey,
      }),
      courseCompleted: new sns.Topic(this, "CourseCompletedTopic", {
        topicName: "lms-course-completed",
        masterKey: kmsKey,
      }),
      deadlineReminder: new sns.Topic(this, "DeadlineReminderTopic", {
        topicName: "lms-deadline-reminder",
        masterKey: kmsKey,
      }),
      coursePublished: new sns.Topic(this, "CoursePublishedTopic", {
        topicName: "lms-course-published",
        masterKey: kmsKey,
      }),
      certificateReady: new sns.Topic(this, "CertificateReadyTopic", {
        topicName: "lms-certificate-ready",
        masterKey: kmsKey,
      }),
    };

    // ── SQS Queues with DLQs ──────────────────────────────────────────
    // Architecture doc section 2.3: DLQ on each, visibility timeout 30s
    const makeQueue = (name: string): { queue: sqs.Queue; dlq: sqs.Queue } => {
      const dlq = new sqs.Queue(this, `${name}Dlq`, {
        queueName: `lms-${name}-dlq`,
        retentionPeriod: cdk.Duration.days(14),
        encryptionMasterKey: kmsKey,
      });
      const queue = new sqs.Queue(this, `${name}Queue`, {
        queueName: `lms-${name}`,
        visibilityTimeout: cdk.Duration.seconds(30),
        retentionPeriod: cdk.Duration.days(4),
        encryptionMasterKey: kmsKey,
        deadLetterQueue: { queue: dlq, maxReceiveCount: 3 },
      });
      return { queue, dlq };
    };

    const autoGrade = makeQueue("auto-grade");
    const progress = makeQueue("progress");
    const notification = makeQueue("notification");
    const logIngestion = makeQueue("log-ingestion");

    // Wire SNS → SQS subscriptions
    this.snsTopics.gradeReleased.addSubscription(
      new (require("aws-cdk-lib/aws-sns-subscriptions").SqsSubscription)(notification.queue)
    );
    this.snsTopics.enrolmentConfirmed.addSubscription(
      new (require("aws-cdk-lib/aws-sns-subscriptions").SqsSubscription)(notification.queue)
    );
    this.snsTopics.courseCompleted.addSubscription(
      new (require("aws-cdk-lib/aws-sns-subscriptions").SqsSubscription)(notification.queue)
    );

    this.sqsQueues = {
      autoGrade: autoGrade.queue,
      autoGradeDlq: autoGrade.dlq,
      progress: progress.queue,
      progressDlq: progress.dlq,
      notification: notification.queue,
      notificationDlq: notification.dlq,
      logIngestion: logIngestion.queue,
      logIngestionDlq: logIngestion.dlq,
    };

    // ── Outputs ──────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "RdsEndpoint", { value: this.rdsEndpoint, exportName: "LmsRdsEndpoint" });
    new cdk.CfnOutput(this, "RedisEndpoint", { value: this.redisEndpoint, exportName: "LmsRedisEndpoint" });
    new cdk.CfnOutput(this, "ContentBucketName", { value: this.contentBucket.bucketName, exportName: "LmsContentBucket" });
  }
}
