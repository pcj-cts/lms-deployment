import * as cdk from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as iam from "aws-cdk-lib/aws-iam";
import * as kms from "aws-cdk-lib/aws-kms";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import { Construct } from "constructs";

export interface SecurityGroups {
  alb: ec2.SecurityGroup;
  ecs: ec2.SecurityGroup;
  rds: ec2.SecurityGroup;
  redis: ec2.SecurityGroup;
}

export class LmsFoundationStack extends cdk.Stack {
  public readonly vpc: ec2.Vpc;
  public readonly securityGroups: SecurityGroups;
  public readonly kmsKey: kms.Key;
  public readonly dbSecret: secretsmanager.Secret;
  public readonly jwtSecret: secretsmanager.Secret;
  public readonly ecsTaskExecutionRole: iam.Role;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    // ── KMS Customer Managed Key ─────────────────────────────────────
    // Single CMK used for RDS, S3, DynamoDB encryption per architecture doc.
    this.kmsKey = new kms.Key(this, "LmsKmsKey", {
      alias: "alias/lms-cmk",
      description: "LMS Customer Managed Key – RDS, S3, DynamoDB encryption",
      enableKeyRotation: true,          // Annual automatic rotation
      rotationPeriod: cdk.Duration.days(365),
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // ── Secrets Manager ──────────────────────────────────────────────
    // DB credentials auto-rotate every 30 days per architecture doc section 2.5
    this.dbSecret = new secretsmanager.Secret(this, "LmsDbSecret", {
      secretName: "lms/production/db-credentials",
      description: "LMS RDS PostgreSQL master credentials",
      encryptionKey: this.kmsKey,
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ username: "lmsadmin" }),
        generateStringKey: "password",
        excludeCharacters: "\"@/\\",
        passwordLength: 32,
      },
    });

    this.jwtSecret = new secretsmanager.Secret(this, "LmsJwtSecret", {
      secretName: "lms/production/jwt-secret",
      description: "LMS JWT signing secret for Auth service",
      encryptionKey: this.kmsKey,
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ algorithm: "HS256" }),
        generateStringKey: "secret",
        excludeCharacters: "\"@/\\",
        passwordLength: 64,
      },
    });

    // ── VPC ──────────────────────────────────────────────────────────
    // 3-tier subnet design per architecture doc section 6.1:
    //   Public   → ALB, NAT Gateway
    //   Private  → ECS Fargate tasks
    //   Isolated → RDS, ElastiCache (no internet access)
    this.vpc = new ec2.Vpc(this, "LmsVpc", {
      vpcName: "lms-vpc",
      ipAddresses: ec2.IpAddresses.cidr("10.0.0.0/16"),
      maxAzs: 2,                         // ap-south-1a and ap-south-1b
      natGateways: 2,                    // 1 per AZ per architecture doc
      subnetConfiguration: [
        {
          cidrMask: 24,
          name: "Public",
          subnetType: ec2.SubnetType.PUBLIC,
        },
        {
          cidrMask: 24,
          name: "Private",
          subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
        },
        {
          cidrMask: 24,
          name: "Isolated",
          subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
        },
      ],
    });

    // VPC Flow Logs for audit/security
    this.vpc.addFlowLog("LmsVpcFlowLog", {
      destination: ec2.FlowLogDestination.toCloudWatchLogs(),
    });

    // ── Security Groups ──────────────────────────────────────────────
    // Matches architecture doc section 6.2 exactly:
    //   sg-alb   → 443 inbound from internet, 8080 outbound to sg-ecs
    //   sg-ecs   → 8080 from sg-alb, outbound to RDS/Redis/internet via NAT
    //   sg-rds   → 5432 from sg-ecs only
    //   sg-redis → 6379 from sg-ecs only
    const albSg = new ec2.SecurityGroup(this, "AlbSecurityGroup", {
      vpc: this.vpc,
      securityGroupName: "sg-lms-alb",
      description: "LMS ALB – HTTPS inbound from internet",
      allowAllOutbound: false,
    });
    albSg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443), "HTTPS from internet");
    albSg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(80), "HTTP redirect");

    const ecsSg = new ec2.SecurityGroup(this, "EcsSecurityGroup", {
      vpc: this.vpc,
      securityGroupName: "sg-lms-ecs",
      description: "LMS ECS Fargate tasks – port 8080 from ALB only",
      allowAllOutbound: false,
    });
    ecsSg.addIngressRule(albSg, ec2.Port.tcp(8080), "App traffic from ALB");
    // Outbound: HTTPS for AWS service API calls (SES, S3, SNS, Secrets Manager)
    ecsSg.addEgressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443), "HTTPS outbound via NAT");

    const rdsSg = new ec2.SecurityGroup(this, "RdsSecurityGroup", {
      vpc: this.vpc,
      securityGroupName: "sg-lms-rds",
      description: "LMS RDS PostgreSQL – port 5432 from ECS only",
      allowAllOutbound: false,
    });
    rdsSg.addIngressRule(ecsSg, ec2.Port.tcp(5432), "PostgreSQL from ECS");

    const redisSg = new ec2.SecurityGroup(this, "RedisSecurityGroup", {
      vpc: this.vpc,
      securityGroupName: "sg-lms-redis",
      description: "LMS ElastiCache Redis – port 6379 from ECS only",
      allowAllOutbound: false,
    });
    redisSg.addIngressRule(ecsSg, ec2.Port.tcp(6379), "Redis from ECS");

    // Allow ALB to forward to ECS
    albSg.addEgressRule(ecsSg, ec2.Port.tcp(8080), "Forward to ECS tasks");

    this.securityGroups = {
      alb: albSg,
      ecs: ecsSg,
      rds: rdsSg,
      redis: redisSg,
    };

    // ── ECS Task Execution Role ──────────────────────────────────────
    // Least-privilege IAM role per architecture doc section 2.5
    this.ecsTaskExecutionRole = new iam.Role(this, "EcsTaskExecutionRole", {
      roleName: "lms-ecs-task-execution-role",
      assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName(
          "service-role/AmazonECSTaskExecutionRolePolicy"
        ),
      ],
    });

    // Allow reading secrets and KMS decrypt
    this.ecsTaskExecutionRole.addToPolicy(
      new iam.PolicyStatement({
        sid: "ReadLmsSecrets",
        actions: ["secretsmanager:GetSecretValue", "kms:Decrypt"],
        resources: [this.dbSecret.secretArn, this.jwtSecret.secretArn, this.kmsKey.keyArn],
      })
    );

    // Allow writing CloudWatch logs
    this.ecsTaskExecutionRole.addToPolicy(
      new iam.PolicyStatement({
        sid: "WriteLogs",
        actions: ["logs:CreateLogStream", "logs:PutLogEvents"],
        resources: ["*"],
      })
    );

    // ── Outputs ──────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "VpcId", { value: this.vpc.vpcId, exportName: "LmsVpcId" });
    new cdk.CfnOutput(this, "KmsKeyArn", { value: this.kmsKey.keyArn, exportName: "LmsKmsKeyArn" });
    new cdk.CfnOutput(this, "DbSecretArn", { value: this.dbSecret.secretArn, exportName: "LmsDbSecretArn" });
  }
}
