import * as cdk from "aws-cdk-lib";
import * as codepipeline from "aws-cdk-lib/aws-codepipeline";
import * as codepipeline_actions from "aws-cdk-lib/aws-codepipeline-actions";
import * as codebuild from "aws-cdk-lib/aws-codebuild";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecs from "aws-cdk-lib/aws-ecs";
import * as iam from "aws-cdk-lib/aws-iam";
import * as logs from "aws-cdk-lib/aws-logs";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import { Construct } from "constructs";

interface PipelineStackProps extends cdk.StackProps {
  ecsServices: Record<string, ecs.FargateService>;
  ecrRepos: Record<string, ecr.Repository>;
  githubOwner: string;
  githubRepo: string;
  githubBranch: string;
}

export class LmsPipelineStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: PipelineStackProps) {
    super(scope, id, props);
    const { ecsServices, ecrRepos, githubOwner, githubRepo, githubBranch } = props;

    // GitHub OAuth token stored in Secrets Manager
    // Run: aws secretsmanager create-secret --name lms/github-token --secret-string '{"token":"ghp_xxx"}'
    const githubToken = secretsmanager.Secret.fromSecretNameV2(
      this, "GithubToken", "lms/github-token"
    );

    // SonarQube token for quality gate integration
    const sonarToken = secretsmanager.Secret.fromSecretNameV2(
      this, "SonarToken", "lms/sonarqube-token"
    );

    // ── CodeBuild role with ECR and ECS permissions ───────────────────
    const buildRole = new iam.Role(this, "CodeBuildRole", {
      roleName: "lms-codebuild-role",
      assumedBy: new iam.ServicePrincipal("codebuild.amazonaws.com"),
    });

    buildRole.addToPolicy(new iam.PolicyStatement({
      sid: "EcrAccess",
      actions: [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
      ],
      resources: ["*"],
    }));
    buildRole.addToPolicy(new iam.PolicyStatement({
      sid: "SecretsAccess",
      actions: ["secretsmanager:GetSecretValue"],
      resources: [githubToken.secretArn, sonarToken.secretArn],
    }));
    buildRole.addToPolicy(new iam.PolicyStatement({
      sid: "EcsDeployAccess",
      actions: ["ecs:RegisterTaskDefinition", "ecs:DescribeTaskDefinition", "iam:PassRole"],
      resources: ["*"],
    }));

    // ── Shared build environment ──────────────────────────────────────
    const buildEnv: codebuild.BuildEnvironment = {
      buildImage: codebuild.LinuxBuildImage.STANDARD_7_0,
      computeType: codebuild.ComputeType.MEDIUM,
      privileged: true,                    // Required for Docker-in-Docker
    };

    // ── Stage 2: Lint + Static Analysis ──────────────────────────────
    const lintProject = new codebuild.Project(this, "LintProject", {
      projectName: "lms-lint",
      role: buildRole,
      environment: buildEnv,
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "LintLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          install: { commands: ["mvn --version", "node --version"] },
          build: {
            commands: [
              // Java: Checkstyle + SpotBugs via Maven
              "mvn checkstyle:check spotbugs:check -pl services/ --no-transfer-progress",
              // Frontend: ESLint
              "cd frontend && npm ci && npm run lint",
            ],
          },
        },
      }),
    });

    // ── Stage 3: Unit Tests + Coverage Gate ──────────────────────────
    // Fails if JaCoCo coverage < 80% per architecture doc F011
    const unitTestProject = new codebuild.Project(this, "UnitTestProject", {
      projectName: "lms-unit-tests",
      role: buildRole,
      environment: buildEnv,
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "UnitTestLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          build: {
            commands: [
              // Run tests with JaCoCo; Maven enforcer fails if coverage < 80%
              "mvn test jacoco:report jacoco:check -pl services/ --no-transfer-progress",
              // Coverage gate: fail if overall line coverage < 80%
              "mvn verify -Djacoco.haltOnFailure=true --no-transfer-progress",
            ],
          },
        },
        reports: {
          "lms-test-reports": {
            files: ["**/surefire-reports/*.xml"],
            "file-format": "JUNITXML",
          },
          "lms-coverage-reports": {
            files: ["**/jacoco-ut/jacoco.xml"],
            "file-format": "JACOCOXML",
          },
        },
        artifacts: {
          files: ["**/target/site/jacoco/**"],
          name: "coverage-reports",
        },
      }),
    });

    // ── Stage 4: Integration Tests ────────────────────────────────────
    const integrationTestProject = new codebuild.Project(this, "IntegrationTestProject", {
      projectName: "lms-integration-tests",
      role: buildRole,
      environment: buildEnv,
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "IntegrationTestLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          install: {
            commands: [
              // Testcontainers needs Docker socket
              "nohup /usr/local/bin/dockerd &",
              "timeout 15 sh -c 'until docker info; do sleep 1; done'",
            ],
          },
          build: {
            commands: [
              // Spring Boot Test + Testcontainers (spins up real PostgreSQL + Redis)
              "mvn failsafe:integration-test failsafe:verify -pl services/ --no-transfer-progress",
            ],
          },
        },
      }),
    });

    // ── Stage 5: Docker Build + ECR Push ─────────────────────────────
    const serviceNames = Object.keys(ecrRepos);
    const buildAndPushProject = new codebuild.Project(this, "BuildPushProject", {
      projectName: "lms-build-push",
      role: buildRole,
      environment: buildEnv,
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "BuildPushLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        env: {
          variables: {
            AWS_ACCOUNT_ID: this.account,
            AWS_REGION: this.region,
          },
        },
        phases: {
          pre_build: {
            commands: [
              // Authenticate Docker to ECR
              "aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com",
              "COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-8)",
              "IMAGE_TAG=${COMMIT_HASH:=latest}",
            ],
          },
          build: {
            commands: [
              // Maven build all service JARs
              "mvn package -DskipTests --no-transfer-progress -pl services/",
              // Build and push each service image
              ...serviceNames.flatMap((name) => {
                const repoUri = ecrRepos[name].repositoryUri;
                return [
                  `docker build -t ${repoUri}:$IMAGE_TAG -t ${repoUri}:latest services/${name}/`,
                  `docker push ${repoUri}:$IMAGE_TAG`,
                  `docker push ${repoUri}:latest`,
                  // Write imagedefinitions.json for CodeDeploy
                  `printf '[{"name":"${name}","imageUri":"${repoUri}:%s"}]' $IMAGE_TAG > imagedefinitions-${name}.json`,
                ];
              }),
            ],
          },
        },
        artifacts: {
          files: ["imagedefinitions-*.json"],
          name: "build-output",
        },
      }),
    });

    // ── Stage 7: SonarQube Quality Gate ──────────────────────────────
    // Architecture doc F011: 0 blockers, 0 criticals, coverage >= 80%.
    // Connects to external SonarQube (replace SONAR_HOST with your instance URL).
    const sonarProject = new codebuild.Project(this, "SonarProject", {
      projectName: "lms-sonar-gate",
      role: buildRole,
      environment: buildEnv,
      environmentVariables: {
        SONAR_HOST: { value: process.env.SONAR_HOST ?? "https://sonarqube.example.com" },
        SONAR_TOKEN: {
          type: codebuild.BuildEnvironmentVariableType.SECRETS_MANAGER,
          value: `${sonarToken.secretName}:token`,
        },
      },
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "SonarLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          build: {
            commands: [
              // Run Sonar scanner; Maven plugin picks up JaCoCo reports
              "mvn sonar:sonar -Dsonar.host.url=$SONAR_HOST -Dsonar.login=$SONAR_TOKEN --no-transfer-progress -pl services/",
              // Poll quality gate status. Fails build if gate is RED.
              // 0 blockers + 0 criticals + >= 80% coverage must all pass.
              "mvn sonar:sonar -Dsonar.qualitygate.wait=true --no-transfer-progress -pl services/",
            ],
          },
        },
      }),
    });

    // ── Stage 9: Postman Smoke Tests ──────────────────────────────────
    const smokeTestProject = new codebuild.Project(this, "SmokeTestProject", {
      projectName: "lms-smoke-tests",
      role: buildRole,
      environment: buildEnv,
      logging: { cloudWatch: { logGroup: new logs.LogGroup(this, "SmokeTestLogs", { retention: logs.RetentionDays.ONE_WEEK }) } },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          install: { commands: ["npm install -g newman newman-reporter-junitxml"] },
          build: {
            commands: [
              // Run Postman collections against staging endpoint
              "newman run tests/postman/lms-smoke-tests.json --environment tests/postman/staging-env.json --reporters junitxml --reporter-junitxml-export newman-results.xml",
            ],
          },
        },
        reports: {
          "lms-smoke-test-reports": {
            files: ["newman-results.xml"],
            "file-format": "JUNITXML",
          },
        },
      }),
    });

    // ── CodePipeline – 10-stage automated workflow ────────────────────
    // Architecture doc section 2.6 and HLD section 8.1:
    //   Source → Lint → Unit Tests → Integration → Build → Push ECR →
    //   Quality Gate → Deploy Staging → Smoke Tests → Deploy Production

    const sourceOutput = new codepipeline.Artifact("SourceCode");
    const buildOutput = new codepipeline.Artifact("BuildOutput");

    const pipeline = new codepipeline.Pipeline(this, "LmsPipeline", {
      pipelineName: "lms-deployment-pipeline",
      restartExecutionOnUpdate: false,
    });

    // Stage 1: Source – GitHub webhook trigger on push to main
    pipeline.addStage({
      stageName: "Source",
      actions: [
        new codepipeline_actions.GitHubSourceAction({
          actionName: "GitHub_Source",
          owner: githubOwner,
          repo: githubRepo,
          branch: githubBranch,
          oauthToken: cdk.SecretValue.secretsManager("lms/github-token", { jsonField: "token" }),
          output: sourceOutput,
          trigger: codepipeline_actions.GitHubTrigger.WEBHOOK,
        }),
      ],
    });

    // Stage 2: Lint
    pipeline.addStage({
      stageName: "Lint",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "ESLint_Checkstyle",
          project: lintProject,
          input: sourceOutput,
        }),
      ],
    });

    // Stage 3: Unit Tests (BLOCKS if coverage < 80%)
    pipeline.addStage({
      stageName: "UnitTests",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "JUnit_JaCoCo",
          project: unitTestProject,
          input: sourceOutput,
          outputs: [new codepipeline.Artifact("TestReports")],
        }),
      ],
    });

    // Stage 4: Integration Tests
    pipeline.addStage({
      stageName: "IntegrationTests",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "Testcontainers",
          project: integrationTestProject,
          input: sourceOutput,
        }),
      ],
    });

    // Stage 5: Build Docker images
    pipeline.addStage({
      stageName: "Build",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "Docker_Build",
          project: buildAndPushProject,
          input: sourceOutput,
          outputs: [buildOutput],
        }),
      ],
    });

    // Stage 6: SonarQube Quality Gate (BLOCKS on fail)
    pipeline.addStage({
      stageName: "QualityGate",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "SonarQube_Gate",
          project: sonarProject,
          input: sourceOutput,
        }),
      ],
    });

    // Stage 7: Deploy to Staging (blue/green per service)
    pipeline.addStage({
      stageName: "DeployStaging",
      actions: serviceNames.map((name, index) =>
        new codepipeline_actions.EcsDeployAction({
          actionName: `Deploy_${name}_staging`,
          service: ecsServices[name],
          input: buildOutput,
          runOrder: index + 1,
        })
      ),
    });

    // Stage 8: Smoke Tests against staging
    pipeline.addStage({
      stageName: "SmokeTests",
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: "Postman_Newman",
          project: smokeTestProject,
          input: sourceOutput,
        }),
      ],
    });

    // Stage 9: Manual approval before production
    pipeline.addStage({
      stageName: "ApproveProduction",
      actions: [
        new codepipeline_actions.ManualApprovalAction({
          actionName: "Approve_Production_Deploy",
          notifyEmails: [process.env.APPROVAL_EMAIL ?? "team-lead@example.com"],
          additionalInformation: "Smoke tests passed on staging. Review before promoting to production.",
        }),
      ],
    });

    // Stage 10: Deploy to Production (blue/green per service)
    pipeline.addStage({
      stageName: "DeployProduction",
      actions: serviceNames.map((name, index) =>
        new codepipeline_actions.EcsDeployAction({
          actionName: `Deploy_${name}_prod`,
          service: ecsServices[name],
          input: buildOutput,
          runOrder: index + 1,
        })
      ),
    });

    // ── Outputs ──────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "PipelineUrl", {
      value: `https://${this.region}.console.aws.amazon.com/codesuite/codepipeline/pipelines/${pipeline.pipelineName}/view`,
      description: "CodePipeline console URL",
    });
  }
}
