import * as cdk from "aws-cdk-lib";
import * as elbv2 from "aws-cdk-lib/aws-elasticloadbalancingv2";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as cloudfront from "aws-cdk-lib/aws-cloudfront";
import * as origins from "aws-cdk-lib/aws-cloudfront-origins";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as wafv2 from "aws-cdk-lib/aws-wafv2";
import * as route53 from "aws-cdk-lib/aws-route53";
import * as acm from "aws-cdk-lib/aws-certificatemanager";
import * as targets from "aws-cdk-lib/aws-route53-targets";
import { Construct } from "constructs";

interface TrafficStackProps extends cdk.StackProps {
  alb: elbv2.ApplicationLoadBalancer;
  contentBucket: s3.Bucket;
  domainName: string;
}

export class LmsTrafficStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: TrafficStackProps) {
    super(scope, id, props);
    const { alb, contentBucket, domainName } = props;
    const apiDomain = `api.${domainName}`;
    const wsDomain = `ws.${domainName}`;

    // ── Route 53 Hosted Zone ──────────────────────────────────────────
    // Assumes the domain is already registered and a hosted zone exists.
    // If creating a new hosted zone, swap fromLookup for a new HostedZone.
    const hostedZone = route53.HostedZone.fromLookup(this, "LmsHostedZone", {
      domainName,
    });

    // ── ACM Certificates ──────────────────────────────────────────────
    // CloudFront requires a certificate in us-east-1 (global CDN requirement).
    // ALB certificate uses the stack's region (ap-south-1).
    const cfCert = new acm.Certificate(this, "LmsCloudfrontCert", {
      domainName: `*.${domainName}`,
      subjectAlternativeNames: [domainName, apiDomain, wsDomain],
      validation: acm.CertificateValidation.fromDns(hostedZone),
    });

    // ── WAF Web ACL (CloudFront scope) ────────────────────────────────
    // Architecture doc section 2.2: OWASP Top 10 managed rules, rate-based rules.
    // Rate limits per architecture doc section 2.4:
    //   Unauthenticated: 100 req/min = 6000/5min
    //   Authenticated:   300 req/min = 18000/5min
    // WAF rules for CloudFront must be created in us-east-1.
    const wafAcl = new wafv2.CfnWebACL(this, "LmsWafAcl", {
      name: "lms-waf-acl",
      scope: "CLOUDFRONT",
      defaultAction: { allow: {} },
      visibilityConfig: {
        cloudWatchMetricsEnabled: true,
        metricName: "lms-waf",
        sampledRequestsEnabled: true,
      },
      rules: [
        // OWASP Core Rule Set – blocks SQLi, XSS, known bad inputs
        {
          name: "AWSManagedRulesCommonRuleSet",
          priority: 1,
          overrideAction: { none: {} },
          statement: {
            managedRuleGroupStatement: {
              vendorName: "AWS",
              name: "AWSManagedRulesCommonRuleSet",
            },
          },
          visibilityConfig: {
            cloudWatchMetricsEnabled: true,
            metricName: "AWSManagedRulesCommonRuleSet",
            sampledRequestsEnabled: true,
          },
        },
        // SQL injection protection
        {
          name: "AWSManagedRulesSQLiRuleSet",
          priority: 2,
          overrideAction: { none: {} },
          statement: {
            managedRuleGroupStatement: {
              vendorName: "AWS",
              name: "AWSManagedRulesSQLiRuleSet",
            },
          },
          visibilityConfig: {
            cloudWatchMetricsEnabled: true,
            metricName: "AWSManagedRulesSQLiRuleSet",
            sampledRequestsEnabled: true,
          },
        },
        // IP reputation list – blocks known bad actors
        {
          name: "AWSManagedRulesAmazonIpReputationList",
          priority: 3,
          overrideAction: { none: {} },
          statement: {
            managedRuleGroupStatement: {
              vendorName: "AWS",
              name: "AWSManagedRulesAmazonIpReputationList",
            },
          },
          visibilityConfig: {
            cloudWatchMetricsEnabled: true,
            metricName: "AWSManagedRulesAmazonIpReputationList",
            sampledRequestsEnabled: true,
          },
        },
        // Rate limit – unauthenticated: 100 req/min per IP
        {
          name: "RateLimitUnauthenticated",
          priority: 10,
          action: { block: {} },
          statement: {
            rateBasedStatement: {
              limit: 6000,                 // per 5-minute window
              aggregateKeyType: "IP",
            },
          },
          visibilityConfig: {
            cloudWatchMetricsEnabled: true,
            metricName: "RateLimitUnauthenticated",
            sampledRequestsEnabled: true,
          },
        },
      ],
    });

    // ── API Gateway REST API ──────────────────────────────────────────
    // Architecture doc section 2.2: Regional REST API, JWT authoriser Lambda,
    // usage plans with throttling per endpoint.
    const restApi = new apigateway.RestApi(this, "LmsRestApi", {
      restApiName: "lms-api",
      description: "LMS REST API – routes to ALB via VPC Link",
      endpointTypes: [apigateway.EndpointType.REGIONAL],
      deployOptions: {
        stageName: "v1",
        loggingLevel: apigateway.MethodLoggingLevel.INFO,
        dataTraceEnabled: true,
        metricsEnabled: true,
        tracingEnabled: true,              // AWS X-Ray
        throttlingBurstLimit: 500,
        throttlingRateLimit: 1000,
      },
      defaultCorsPreflightOptions: {
        allowOrigins: [`https://${domainName}`, `https://*.${domainName}`],
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: [
          "Content-Type",
          "Authorization",
          "X-Correlation-ID",
          "X-Api-Key",
        ],
      },
    });

    // VPC Link connects API Gateway to the internal ALB
    const vpcLink = new apigateway.VpcLink(this, "LmsVpcLink", {
      vpcLinkName: "lms-vpc-link",
      targets: [alb],
    });

    // Proxy all /api/* requests to the ALB via VPC Link
    const apiResource = restApi.root.addResource("api");
    const proxyResource = apiResource.addResource("{proxy+}");
    proxyResource.addMethod(
      "ANY",
      new apigateway.HttpIntegration(
        `http://${alb.loadBalancerDnsName}/api/{proxy}`,
        {
          httpMethod: "ANY",
          proxy: true,
          options: {
            connectionType: apigateway.ConnectionType.VPC_LINK,
            vpcLink,
            requestParameters: {
              "integration.request.path.proxy": "method.request.path.proxy",
            },
          },
        }
      ),
      {
        requestParameters: { "method.request.path.proxy": true },
      }
    );

    // ── CloudFront Distribution ───────────────────────────────────────
    // Two origins: S3 (frontend SPA), API Gateway (REST API).
    // Architecture doc section 2.2: gzip + Brotli, WAF attached.
    const distribution = new cloudfront.Distribution(this, "LmsCfDistribution", {
      comment: "LMS CloudFront – SPA + API",
      defaultRootObject: "index.html",
      domainNames: [domainName, apiDomain],
      certificate: cfCert,
      webAclId: wafAcl.attrArn,
      enableLogging: true,
      minimumProtocolVersion: cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021,
      // SPA origin: S3 bucket with OAC
      defaultBehavior: {
        origin: origins.S3BucketOrigin.withOriginAccessControl(contentBucket),
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        compress: true,
        allowedMethods: cloudfront.AllowedMethods.ALLOW_GET_HEAD,
        cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
      },
      additionalBehaviors: {
        // API requests: forward to API Gateway, no cache
        "/api/*": {
          origin: new origins.HttpOrigin(
            `${restApi.restApiId}.execute-api.${this.region}.amazonaws.com`,
            { protocolPolicy: cloudfront.OriginProtocolPolicy.HTTPS_ONLY }
          ),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          originRequestPolicy: cloudfront.OriginRequestPolicy.ALL_VIEWER_EXCEPT_HOST_HEADER,
        },
      },
      // Return SPA index.html for all 403/404 so React Router works
      errorResponses: [
        {
          httpStatus: 403,
          responseHttpStatus: 200,
          responsePagePath: "/index.html",
          ttl: cdk.Duration.seconds(0),
        },
        {
          httpStatus: 404,
          responseHttpStatus: 200,
          responsePagePath: "/index.html",
          ttl: cdk.Duration.seconds(0),
        },
      ],
    });

    // ── API Gateway WebSocket ─────────────────────────────────────────
    // Architecture doc section 2.2: WebSocket for real-time in-app notifications.
    // Connections auto-close after 2 hours of inactivity (API GW default).
    const wsApi = new apigateway.CfnApiV2 !== undefined
      ? new (require("aws-cdk-lib/aws-apigatewayv2").WebSocketApi)(
          this,
          "LmsWebSocketApi",
          {
            apiName: "lms-websocket-api",
            connectRouteOptions: {
              integration: new (require("aws-cdk-lib/aws-apigatewayv2-integrations")
                .WebSocketLambdaIntegration)(
                "WsConnect",
                new (require("aws-cdk-lib/aws-lambda").Function)(
                  this,
                  "WsConnectFn",
                  {
                    runtime: (require("aws-cdk-lib/aws-lambda").Runtime).JAVA_21,
                    handler: "com.lms.notification.ws.ConnectHandler",
                    code: (require("aws-cdk-lib/aws-lambda").Code).fromAsset(
                      "lambda/ws-connect"
                    ),
                    timeout: cdk.Duration.seconds(30),
                  }
                )
              ),
            },
          }
        )
      : null;

    // ── Route 53 DNS Records ──────────────────────────────────────────
    new route53.ARecord(this, "LmsApexRecord", {
      zone: hostedZone,
      target: route53.RecordTarget.fromAlias(
        new targets.CloudFrontTarget(distribution)
      ),
      recordName: domainName,
    });

    new route53.ARecord(this, "LmsApiRecord", {
      zone: hostedZone,
      target: route53.RecordTarget.fromAlias(
        new targets.CloudFrontTarget(distribution)
      ),
      recordName: apiDomain,
    });

    // ── Outputs ──────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "CloudFrontUrl", {
      value: `https://${distribution.distributionDomainName}`,
      exportName: "LmsCloudFrontUrl",
    });
    new cdk.CfnOutput(this, "ApiGatewayUrl", {
      value: restApi.url,
      exportName: "LmsApiGatewayUrl",
    });
    new cdk.CfnOutput(this, "RestApiId", {
      value: restApi.restApiId,
      exportName: "LmsRestApiId",
    });
  }
}
