import * as cdk from "aws-cdk-lib";
import { Template, Match } from "aws-cdk-lib/assertions";
import { LmsFoundationStack } from "../lib/stacks/foundation-stack";

describe("LmsFoundationStack", () => {
  let template: Template;

  beforeAll(() => {
    const app = new cdk.App();
    const stack = new LmsFoundationStack(app, "TestFoundationStack", {
      env: { account: "123456789012", region: "ap-south-1" },
    });
    template = Template.fromStack(stack);
  });

  test("VPC has 3 subnet tiers across 2 AZs", () => {
    template.resourceCountIs("AWS::EC2::Subnet", 6); // 3 types × 2 AZs
  });

  test("NAT Gateways: 2 (one per AZ)", () => {
    template.resourceCountIs("AWS::EC2::NatGateway", 2);
  });

  test("KMS key has annual rotation enabled", () => {
    template.hasResourceProperties("AWS::KMS::Key", {
      EnableKeyRotation: true,
    });
  });

  test("DB secret uses KMS CMK encryption", () => {
    template.hasResourceProperties("AWS::SecretsManager::Secret", {
      Name: "lms/production/db-credentials",
      KmsKeyId: Match.anyValue(),
    });
  });

  test("ALB security group allows only port 443 inbound", () => {
    template.hasResourceProperties("AWS::EC2::SecurityGroup", {
      GroupDescription: Match.stringLikeRegexp("ALB"),
      SecurityGroupIngress: Match.arrayWith([
        Match.objectLike({ FromPort: 443, ToPort: 443 }),
      ]),
    });
  });

  test("RDS security group allows only port 5432 from ECS SG", () => {
    template.hasResourceProperties("AWS::EC2::SecurityGroup", {
      GroupDescription: Match.stringLikeRegexp("RDS PostgreSQL"),
      SecurityGroupIngress: Match.arrayWith([
        Match.objectLike({ FromPort: 5432, ToPort: 5432 }),
      ]),
    });
  });

  test("VPC Flow Logs are enabled", () => {
    template.resourceCountIs("AWS::EC2::FlowLog", 1);
  });
});
